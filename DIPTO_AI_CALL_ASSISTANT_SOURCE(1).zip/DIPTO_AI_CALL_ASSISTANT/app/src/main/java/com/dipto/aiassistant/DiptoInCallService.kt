package com.dipto.aiassistant

import android.telecom.Call
import android.telecom.InCallService
import android.util.Log

class DiptoInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.i("DiptoAI", "Telecom call event received")
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        Log.i("DiptoAI", "Telecom call event ended")
    }
}
