package com.dipto.aiassistant

import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF080D0C)
private val Panel = Color(0xFF14211D)
private val Mint = Color(0xFF62D6A6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DiptoApp(onSetDialer = { requestDialerRole() }) }
    }

    private fun requestDialerRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
                startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER))
            }
        } else {
            startActivity(Intent("android.telecom.action.CHANGE_DEFAULT_DIALER"))
        }
    }
}

@Composable
fun DiptoApp(onSetDialer: () -> Unit) {
    var enabled by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Mint,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home", "History", "Blocked", "Settings").forEachIndexed { i, label ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(
                            when(i) {
                                0 -> Icons.Default.Call
                                1 -> Icons.Default.History
                                2 -> Icons.Default.Block
                                else -> Icons.Default.Settings
                            }, contentDescription = label
                        ) }, label = { Text(label) }
                    )
                }
            }
        }) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState())
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Text("DIPTO AI", color = Mint, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("CALL ASSISTANT", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
                when(tab) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel),
                            shape = RoundedCornerShape(22.dp)) {
                            Column(Modifier.fillMaxWidth().padding(22.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("Assistant status", color = Color.LightGray)
                                Text(if(enabled) "ON" else "OFF", color = if(enabled) Mint else Color.White,
                                    fontSize = 38.sp, fontWeight = FontWeight.Bold)
                                Switch(checked = enabled, onCheckedChange = { enabled = it })
                                Text("এটি আপাতত UI control; প্রকৃত AI call answering এখনো যুক্ত নয়.",
                                    color = Color.LightGray, fontSize = 13.sp)
                            }
                        }
                        Button(onClick = onSetDialer, modifier = Modifier.fillMaxWidth()) {
                            Text("Set as default phone app")
                        }
                        InfoCard("Call assistant", "Android call integration placeholder")
                        InfoCard("AI voice", "AI voice service এখনো সংযুক্ত নয়")
                    }
                    1 -> InfoCard("Call history", "এখনো কোনো call history সংরক্ষণ করা হচ্ছে না।")
                    2 -> InfoCard("Blocked numbers", "Blocked-number management এখনো implement করা হয়নি।")
                    else -> {
                        InfoCard("Settings", "পরবর্তী ধাপে permissions, AI provider এবং privacy controls যুক্ত করতে হবে।")
                        InfoCard("Privacy", "কোনো call audio record বা transmit করা হচ্ছে না।")
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoCard(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(detail, color = Color.LightGray, fontSize = 13.sp)
        }
    }
}
