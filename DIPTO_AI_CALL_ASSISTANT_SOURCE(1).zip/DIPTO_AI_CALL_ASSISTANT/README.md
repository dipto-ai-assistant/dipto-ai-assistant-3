# DIPTO AI CALL ASSISTANT

Android starter project for a call-assistant UI and Android Telecom integration point.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK 35, or use the included GitHub Actions workflow.

## Current implementation status
- Compose dashboard with Home, History, Blocked and Settings sections.
- Default phone app role request.
- InCallService event hooks.
- No AI voice answering, call audio capture, call recording, cloud service, real call history or persistent blocklist is implemented.
- The ON/OFF switch is currently UI-only.

Real call-audio features require a transparent user experience, appropriate permissions and consent, plus a secure server-side AI service. Never embed API keys in the APK.
