# DIPTO AI Call Assistant — UI Prototype

This starter contains a dark dashboard, prototype status toggle, history placeholder, and local excluded-number settings.

**Important:** This is a UI prototype only. It does not answer SIM calls, access call logs, record audio, or connect to an AI voice service. The status toggle is visual/demo state only.

Build from the `android/` directory with `gradle assembleDebug`.
