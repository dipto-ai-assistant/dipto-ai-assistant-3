# DIPTO AI Call Assistant — Starter Prototype

This repository contains a minimal Android Kotlin starter app and GitHub Actions workflow for building a debug APK.

**Important:** It does not yet answer live SIM phone calls or connect to an AI voice service. Real call handling requires careful Android telephony integration, user permissions/default call-role support, and a backend/voice service.

To build: GitHub Actions → Build DIPTO AI APK → Run workflow. Download the artifact after a successful build.
