package com.dipto.aiassistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 13, 22)
    private val panel = Color.rgb(19, 26, 39)
    private val panel2 = Color.rgb(25, 34, 49)
    private val accent = Color.rgb(72, 204, 232)
    private val muted = Color.rgb(150, 164, 184)
    private var assistantEnabled = false
    private lateinit var body: LinearLayout
    private lateinit var pageTitle: TextView
    private val prefs by lazy { getSharedPreferences("dipto_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        assistantEnabled = prefs.getBoolean("assistant_enabled", false)
        showDashboard()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(16), dp(18), dp(16)); background = rounded(panel); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) } }
    private fun addText(parent: LinearLayout, value: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0) {
        parent.addView(text(value, size, color, bold), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
    }
    private fun base(title: String, tab: String): LinearLayout {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(22), dp(22), dp(8)) }
        header.addView(text("DIPTO AI", 13f, accent, true))
        pageTitle = text(title, 27f, Color.WHITE, true)
        header.addView(pageTitle, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        outer.addView(header)
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(18)) }
        scroll.addView(body)
        outer.addView(scroll, LinearLayout.LayoutParams(0, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(8)); background = rounded(panel) }
        fun navBtn(label: String, target: String) {
            val b = TextView(this).apply { text = label; textSize = 13f; gravity = Gravity.CENTER; setTextColor(if (tab == target) accent else muted); setPadding(dp(4), dp(12), dp(4), dp(12)) }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f)); b.setOnClickListener { when(target) { "home" -> showDashboard(); "history" -> showHistory(); else -> showSettings() } }
        }
        navBtn("⌂  Home", "home"); navBtn("◷  History", "history"); navBtn("⚙  Settings", "settings")
        outer.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { leftMargin = dp(14); rightMargin = dp(14); topMargin = dp(4); bottomMargin = dp(14) })
        setContentView(outer)
        return body
    }

    private fun showDashboard() {
        val b = base("Call Assistant", "home")
        addText(b, "Your AI call companion", 14f, muted, top = 2)
        val status = card()
        status.background = rounded(panel2)
        addText(status, "ASSISTANT STATUS", 12f, muted, true)
        addText(status, if (assistantEnabled) "●  Ready (prototype)" else "○  Paused", 20f, if (assistantEnabled) accent else Color.WHITE, true, 10)
        addText(status, "Call answering is not connected in this prototype.", 13f, muted, top = 8)
        val toggle = Button(this).apply { text = if (assistantEnabled) "Pause prototype" else "Enable prototype"; setTextColor(Color.BLACK); background = rounded(accent, 12) }
        status.addView(toggle, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(16) })
        toggle.setOnClickListener { assistantEnabled = !assistantEnabled; prefs.edit().putBoolean("assistant_enabled", assistantEnabled).apply(); showDashboard() }
        b.addView(status)
        val info = card(); addText(info, "QUICK OVERVIEW", 12f, muted, true); addText(info, "Call answering", 16f, Color.WHITE, true, 12); addText(info, "Not connected yet", 13f, muted, top = 5); addText(info, "Excluded numbers", 16f, Color.WHITE, true, 16); addText(info, "${getNumbers().size} saved", 13f, muted, top = 5); b.addView(info)
        val note = card(); addText(note, "Prototype notice", 15f, Color.WHITE, true); addText(note, "The status switch is only a UI demo. It does not answer calls or activate microphone/telephony services.", 13f, muted, top = 8); b.addView(note)
    }

    private fun showHistory() {
        val b = base("Call History", "history")
        val empty = card(); addText(empty, "No call records yet", 18f, Color.WHITE, true); addText(empty, "Call history will appear here once call integration is developed. This prototype does not read your phone's call log.", 13f, muted, top = 8); b.addView(empty)
        val demo = card(); addText(demo, "Privacy", 15f, Color.WHITE, true); addText(demo, "This starter screen stores no call audio or caller records.", 13f, muted, top = 8); b.addView(demo)
    }

    private fun getNumbers(): MutableSet<String> = prefs.getStringSet("excluded_numbers", emptySet())?.toMutableSet() ?: mutableSetOf()
    private fun showSettings() {
        val b = base("Settings", "settings")
        val exclusion = card(); addText(exclusion, "Excluded numbers", 18f, Color.WHITE, true); addText(exclusion, "Numbers listed here are reserved for the future call-routing feature. No call handling is active yet.", 13f, muted, top = 8)
        val input = EditText(this).apply { hint = "Enter phone number"; setHintTextColor(muted); setTextColor(Color.WHITE); textSize = 15f; inputType = 3; background = rounded(panel2); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        exclusion.addView(input, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(14) })
        val add = Button(this).apply { text = "Add number"; setTextColor(Color.BLACK); background = rounded(accent, 12) }
        exclusion.addView(add, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        exclusion.addView(list, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        fun refresh() {
            list.removeAllViews()
            getNumbers().sorted().forEach { number ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), dp(8), dp(6), dp(8)); background = rounded(panel2) }
                row.addView(text(number, 15f, Color.WHITE), LinearLayout.LayoutParams(0, -2, 1f))
                val remove = TextView(this).apply { text = "Remove"; setTextColor(Color.rgb(255, 125, 130)); textSize = 13f; setPadding(dp(12), dp(8), dp(12), dp(8)) }
                row.addView(remove); remove.setOnClickListener { val set = getNumbers(); set.remove(number); prefs.edit().putStringSet("excluded_numbers", set).apply(); refresh() }
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            }
            if (getNumbers().isEmpty()) list.addView(text("No excluded numbers added.", 13f, muted))
        }
        add.setOnClickListener { val number = input.text.toString().trim(); if (number.isNotEmpty()) { val set = getNumbers(); set.add(number); prefs.edit().putStringSet("excluded_numbers", set).apply(); input.setText(""); refresh() } else Toast.makeText(this, "Enter a number first", Toast.LENGTH_SHORT).show() }
        refresh(); b.addView(exclusion)
        val about = card(); addText(about, "About", 16f, Color.WHITE, true); addText(about, "DIPTO AI Call Assistant\nPrototype UI • Version 0.2", 13f, muted, top = 8); b.addView(about)
    }
}
